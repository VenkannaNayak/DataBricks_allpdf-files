SELECT count(*)
FROM [WideWorldImportersDW].[Fact].[Order]
