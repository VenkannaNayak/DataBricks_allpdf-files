SELECT TOP (1000) *
  FROM [WideWorldImportersDW].[Fact].[Order];
