SELECT [Order Year],
       [Order Month],
	  [Order],
	  [Stock Item],
	  [Customer],
	  [WWI Order],
	  [WWI Backorder]       
FROM [dbo].[v_Backorders];
