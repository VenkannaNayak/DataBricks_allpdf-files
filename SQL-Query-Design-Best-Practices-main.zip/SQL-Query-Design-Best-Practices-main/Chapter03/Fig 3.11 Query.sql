SELECT TOP 3 CONVERT(VARCHAR, [Date],  12) AS 'Date'
FROM [Dimension].[Date] 