SELECT TOP 3 CONVERT(VARCHAR, CAST([Date] AS Datetime),  113) AS [Date] 
FROM [Dimension].[Date] 