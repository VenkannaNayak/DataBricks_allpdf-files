SELECT CONVERT(numeric, 102.55268) AS NumericNumber
	  ,CONVERT(int, 102.55268) AS IntegerNumber