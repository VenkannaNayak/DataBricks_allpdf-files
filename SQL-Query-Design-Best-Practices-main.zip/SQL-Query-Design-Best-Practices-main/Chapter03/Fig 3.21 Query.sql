SELECT TOP (3) [Order Key]
			  ,[Description] 
FROM [Fact].[Order] 