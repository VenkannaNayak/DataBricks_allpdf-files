SELECT TOP (3) [Order Key]
			  ,[Description] AS [Product Description]
FROM [Fact].[Order] 