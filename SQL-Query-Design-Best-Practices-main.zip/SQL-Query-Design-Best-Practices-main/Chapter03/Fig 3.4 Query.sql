SELECT TOP(3) FORMAT( [Date], 'MM-dd-yyyy') AS 'Date' 
FROM [Dimension].[Date] 