SELECT FORMAT( [Date], 'yyyy/MM/dd') AS 'Date'
FROM [Dimension].[Date] 