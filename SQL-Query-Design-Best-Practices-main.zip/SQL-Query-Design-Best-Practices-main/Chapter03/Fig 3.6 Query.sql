SELECT TOP( 3) FORMAT( [Date], 'yyyy') AS 'Year'
FROM [Dimension].[Date] 