SELECT TOP(3) FORMAT( [Date], 'MM/dd/yyyy HH:mm tt') AS 'Date'   
FROM [Dimension].[Date] 