SELECT TOP 3 FORMAT([Tax Rate]/100,'00.00%') 'Tax Rate'
FROM [Fact].[Sale] 