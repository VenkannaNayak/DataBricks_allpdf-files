Select TOP (1) ISJSON (CustomerOrderHistory) from DBO.CustomerOrders;
