SELECT JSON_OBJECT ('name':'Steve','role':'author');
